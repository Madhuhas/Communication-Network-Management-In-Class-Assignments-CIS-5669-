#Kotini Sai Madhuhas
#2024.02.03
#string examples

str ="Sai Madhuhas Kotini"
print(str)
print(str[0])
print(str[2:5])
print(str[2:])
print(str*2)
print(str+' MaD')

hello = 'Hello World!'
name2=hello[0:6]+'MaD'
print(name2)

print("My Name is %s and my weight is %d" %('Sai',63))

#triple quotes
auden_attriute="""
"In the deserts of the heat
\tLet the healing fountain start,
In the prision of his days
\tTeach the free man how to praise."
\n(In thhe Memory of W.B.Yeats: w.h.auden)
"""
print(auden_attriute)


