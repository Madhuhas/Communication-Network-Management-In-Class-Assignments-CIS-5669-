# Sai Madhuhas Kotini
# 2024.01.20
# Decision Making

var = 100
if(var == 100): print('value is 100')

var1 = 100
if(var1):
    print('true statement')

var2 = 100
if(var2):
    print('true statement')
else:
    pass    